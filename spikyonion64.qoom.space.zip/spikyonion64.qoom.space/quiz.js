//Global Variables
//This is where you will define the variables you will be using in your project.
var questionsAnswered = 0;
var EndoScore = 0;
var MesoScore = 0;
var EctoScore = 0;
var result = document.getElementById("result");
var reset = document.getElementById("reset");

var q1a1 = document.getElementById("q1a1");
var q1a2 = document.getElementById("q1a2");
var q1a3 = document.getElementById("q1a3");

var q2a1 = document.getElementById("q2a1");
var q2a2 = document.getElementById("q2a2");
var q2a3 = document.getElementById("q2a3");

var q3a1 = document.getElementById("q3a1");
var q3a2 = document.getElementById("q3a2");
var q3a3 = document.getElementById("q3a3");

var q4a1 = document.getElementById("q4a1");
var q4a2 = document.getElementById("q4a2");
var q4a3 = document.getElementById("q4a3");

var q5a1 = document.getElementById("q5a1");
var q5a2 = document.getElementById("q5a2");
var q5a3 = document.getElementById("q5a3");

var q6a1 = document.getElementById("q6a1");
var q6a2 = document.getElementById("q6a2");
var q6a3 = document.getElementById("q6a3");

var q7a1 = document.getElementById("q7a1");
var q7a2 = document.getElementById("q7a2");
var q7a3 = document.getElementById("q7a3");

q1a1.addEventListener("click", ectomorph);
q1a2.addEventListener("click", mesomorph);
q1a3.addEventListener("click", endomorph);

q2a1.addEventListener("click", ectomorph);
q2a2.addEventListener("click", mesomorph);
q2a3.addEventListener("click", endomorph);

q3a1.addEventListener("click", ectomorph);
q3a2.addEventListener("click", mesomorph);
q3a3.addEventListener("click", endomorph);

q4a1.addEventListener("click", ectomorph);
q4a2.addEventListener("click", mesomorph);
q4a3.addEventListener("click", endomorph);

q5a1.addEventListener("click", ectomorph);
q5a2.addEventListener("click", mesomorph);
q5a3.addEventListener("click", endomorph);

q6a1.addEventListener("click", ectomorph);
q6a2.addEventListener("click", mesomorph);
q6a3.addEventListener("click", endomorph);

q7a1.addEventListener("click", ectomorph);
q7a2.addEventListener("click", mesomorph);
q7a3.addEventListener("click", endomorph);

reset.addEventListener("click", resetFunction);

function ectomorph() {
  EctoScore += 1;
  questionsAnswered += 1;
  if (questionsAnswered >= 6) {
    updateResult();
  }
}

function mesomorph() {
  MesoScore += 1;
  questionsAnswered += 1;
  if (questionsAnswered >= 6) {
    updateResult();
  }
}
function endomorph() {
  EndoScore += 1;
  questionsAnswered += 1;
  if (questionsAnswered >= 6) {
    updateResult();
  }
}

function resetFunction() {
  result.innerHTML = "Your result is...";
  var EctoScore = 0;
  var MesoScore = 0;
  var EndoScore = 0;
  var questionsAnswered = 0;
  var EctoScore = 0;
  var MesoScore = 0;
  var EndoScore = 0;
}

function updateResult() {
  if (EctoScore >= 3) {
    result.innerHTML = "You have an ectomorph body!";
  } 
  else if (MesoScore >= 3) {
    result.innerHTML = "You have a mesomorph body!";
  } 
  else if (EndoScore >= 3) {
    result.innerHTML = "You have a endomorph body!";
  } 
  else {
    result.innerHTML = "Continue the quiz!";
  }
}