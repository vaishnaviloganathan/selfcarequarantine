var fullItemList = document.getElementById("my-list");

if (fullItemList) {
  fullItemList.addEventListener("click", checkOffItem, false);
}
function checkOffItem(clicked) {
  if (clicked.targe.tagName == "LI") {
    clicked.target.classList.otggle("all-done");
  }